# INVERTORIA - Sistema de Gestión Inteligente

Una aplicación web moderna construida con Flask que se conecta a una API de FastAPI para proporcionar un sistema completo de autenticación y gestión con diseño inspirado en IA.

## 🚀 Características

### **Diseño y UX**
- ✅ **Diseño Web 4.0** - Interfaz moderna con elementos de IA
- ✅ **Materialize Design** - Framework CSS moderno y responsivo
- ✅ **Colores inspirados en IA** - Paleta de colores futurista
- ✅ **Animaciones fluidas** - Micro-interacciones y efectos visuales
- ✅ **Responsive Design** - Optimizado para todos los dispositivos
- ✅ **PWA Ready** - Capacidades de aplicación web progresiva

### **Funcionalidades**
- ✅ **Sistema de Login/Registro** - Autenticación completa
- ✅ **Validaciones en tiempo real** - UX intuitiva
- ✅ **Gestión de tokens JWT** - Seguridad avanzada
- ✅ **Dashboard interactivo** - Panel de control con IA
- ✅ **Chat con IA** - Asistente virtual integrado
- ✅ **Perfil de usuario** - Gestión de cuenta
- ✅ **Manejo de errores** - Páginas 404/500 personalizadas

### **Seguridad**
- ✅ **Validación de tokens** - Verificación periódica
- ✅ **Timeout de sesión** - Gestión automática de sesiones
- ✅ **Headers de seguridad** - Protección CSRF, XSS, etc.
- ✅ **Validación de formularios** - Sanitización de datos
- ✅ **Encriptación** - Comunicación segura con la API

## 📁 Estructura del Proyecto

```
├── app.py                 # Aplicación principal Flask
├── config.py             # Configuraciones del sistema
├── wsgi.py               # Configuración WSGI para producción
├── requirements.txt      # Dependencias Python
├── Procfile             # Configuración para Heroku/AWS
├── runtime.txt          # Versión de Python
├── templates/           # Plantillas HTML
│   ├── base.html        # Plantilla base
│   ├── login.html       # Página de login
│   ├── register.html    # Página de registro
│   ├── dashboard.html   # Dashboard principal
│   ├── profile.html     # Perfil de usuario
│   ├── 404.html         # Página de error 404
│   └── 500.html         # Página de error 500
├── static/              # Archivos estáticos
│   ├── css/
│   │   └── style.css    # Estilos personalizados
│   ├── js/
│   │   └── app.js       # JavaScript principal
│   ├── sw.js            # Service Worker
│   ├── manifest.json    # Manifiesto PWA
│   └── icons/           # Iconos de la aplicación
└── .env.example         # Variables de entorno ejemplo
```

## 🛠️ Instalación y Configuración

### **1. Clonar y configurar el proyecto**

```bash
# Clonar el repositorio
git clone <repository-url>
cd invertoria-flask

# Crear entorno virtual
python -m venv venv
source venv/bin/activate  # En Windows: venv\Scripts\activate

# Instalar dependencias
pip install -r requirements.txt
```

### **2. Configurar variables de entorno**

```bash
# Copiar archivo de ejemplo
cp .env.example .env

# Editar .env con tus configuraciones
nano .env
```

Variables importantes:
```env
SECRET_KEY=tu-clave-secreta-super-segura
API_BASE_URL=http://localhost:8000/api
JWT_SECRET=tu-clave-jwt-secreta
FLASK_ENV=development
```

### **3. Ejecutar la aplicación**

```bash
# Desarrollo
python app.py

# O usando Flask CLI
export FLASK_APP=app.py
flask run

# Producción con Gunicorn
gunicorn wsgi:app
```

La aplicación estará disponible en: http://localhost:5000

## 🔗 Conexión con la API

La aplicación se conecta a tu API de FastAPI que debe estar ejecutándose en `http://localhost:8000`. 

### **Endpoints utilizados:**
- `POST /api/auth/login` - Autenticación
- `POST /api/auth/register` - Registro de usuarios
- `GET /api/auth/me` - Información del usuario actual

### **Configuración de la API:**
Asegúrate de que tu API de FastAPI tenga CORS configurado para permitir requests desde el frontend:

```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5000"],  # URL del frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

## 🎨 Diseño y Temas

### **Paleta de Colores IA**
- **Primario**: Gradiente azul-púrpura (#667eea → #764ba2)
- **Secundario**: Gradiente rosa-rojo (#f093fb → #f5576c)
- **Acento**: Gradiente azul-cian (#4facfe → #00f2fe)
- **Neural**: Azules y púrpuras para elementos de IA

### **Tipografía**
- **Principal**: Inter (Google Fonts)
- **Monospace**: JetBrains Mono (para código)

### **Componentes Especiales**
- **AI Logo**: Logo animado con efectos de brillo
- **AI Particles**: Partículas flotantes animadas
- **AI Chat**: Chat interactivo con asistente virtual
- **Loading States**: Animaciones de carga personalizadas

## 🔒 Características de Seguridad

### **Autenticación**
- Tokens JWT con expiración
- Validación periódica de tokens
- Logout automático en caso de token inválido

### **Sesiones**
- Timeout automático de sesión (30 minutos)
- Advertencia antes del timeout
- Extensión de sesión disponible

### **Headers de Seguridad**
- Content Security Policy (CSP)
- X-Frame-Options
- X-Content-Type-Options
- Strict-Transport-Security

### **Validaciones**
- Validación en tiempo real de formularios
- Sanitización de datos de entrada
- Protección CSRF
- Validación de fortaleza de contraseñas

## 📱 PWA (Progressive Web App)

La aplicación incluye capacidades PWA:

- **Service Worker**: Cache de recursos para funcionamiento offline
- **Manifest**: Instalable como app nativa
- **Responsive**: Optimizada para móviles
- **Icons**: Iconos para diferentes tamaños de pantalla

## 🚀 Despliegue en AWS

### **Opción 1: AWS Elastic Beanstalk**

```bash
# Instalar EB CLI
pip install awsebcli

# Inicializar aplicación
eb init -p python-3.11 invertoria

# Crear entorno
eb create invertoria-prod

# Desplegar
eb deploy
```

### **Opción 2: AWS EC2 con Docker**

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 5000
CMD ["gunicorn", "wsgi:app", "--bind", "0.0.0.0:5000"]
```

### **Opción 3: AWS Lambda + API Gateway**

Usar Zappa para deployment serverless:

```bash
pip install zappa
zappa init
zappa deploy production
```

## 🔧 Configuración de Producción

### **Variables de Entorno para Producción**
```env
FLASK_ENV=production
SECRET_KEY=tu-clave-super-secreta-de-produccion
API_BASE_URL=https://tu-api-de-produccion.com/api
SESSION_COOKIE_SECURE=True
```

### **Nginx Configuration (si usas EC2)**
```nginx
server {
    listen 80;
    server_name tu-dominio.com;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    
    location /static {
        alias /path/to/app/static;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

## 🧪 Testing

```bash
# Instalar dependencias de testing
pip install pytest pytest-flask

# Ejecutar tests
pytest

# Con coverage
pytest --cov=app
```

## 📊 Monitoreo y Logs

### **Logging Configuration**
```python
import logging
from logging.handlers import RotatingFileHandler

if not app.debug:
    file_handler = RotatingFileHandler('logs/invertoria.log', maxBytes=10240, backupCount=10)
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
```

### **Health Check Endpoint**
```python
@app.route('/health')
def health_check():
    return {'status': 'healthy', 'timestamp': datetime.utcnow().isoformat()}
```

## 🤝 Contribución

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para detalles.

## 🆘 Soporte

Si tienes problemas o preguntas:

1. Revisa la documentación
2. Busca en los issues existentes
3. Crea un nuevo issue con detalles del problema
4. Incluye logs y pasos para reproducir el error

## 🔄 Changelog

### v1.0.0
- ✅ Sistema de autenticación completo
- ✅ Diseño responsivo con Materialize
- ✅ Chat con IA integrado
- ✅ PWA capabilities
- ✅ Seguridad avanzada
- ✅ Listo para producción en AWS

---

**INVERTORIA** - Sistema de Gestión Inteligente impulsado por IA 🤖
</btml:Action>