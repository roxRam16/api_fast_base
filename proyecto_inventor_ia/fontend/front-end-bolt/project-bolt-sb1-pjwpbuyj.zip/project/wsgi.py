"""
WSGI configuration for INVERTORIA Flask application.
This file is used for deployment on AWS, Heroku, or other WSGI servers.
"""

import os
from app import app
from config import config_dict

# Get configuration from environment
config_name = os.environ.get('FLASK_ENV', 'production')
app.config.from_object(config_dict.get(config_name, config_dict['production']))

if __name__ == "__main__":
    # This is used when running locally with `python wsgi.py`
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)