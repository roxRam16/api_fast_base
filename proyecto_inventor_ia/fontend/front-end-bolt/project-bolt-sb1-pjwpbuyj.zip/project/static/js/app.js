// INVERTORIA - Main JavaScript Application
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Materialize components
    initializeMaterialize();
    
    // Initialize custom components
    initializeAIFeatures();
    
    // Initialize form validations
    initializeFormValidations();
    
    // Initialize security features
    initializeSecurityFeatures();
});

function initializeMaterialize() {
    // Initialize sidenav
    var sidenavElems = document.querySelectorAll('.sidenav');
    M.Sidenav.init(sidenavElems);
    
    // Initialize modals
    var modalElems = document.querySelectorAll('.modal');
    M.Modal.init(modalElems);
    
    // Initialize tooltips
    var tooltipElems = document.querySelectorAll('.tooltipped');
    M.Tooltip.init(tooltipElems);
    
    // Initialize dropdowns
    var dropdownElems = document.querySelectorAll('.dropdown-trigger');
    M.Dropdown.init(dropdownElems);
    
    // Initialize collapsibles
    var collapsibleElems = document.querySelectorAll('.collapsible');
    M.Collapsible.init(collapsibleElems);
    
    // Initialize select elements
    var selectElems = document.querySelectorAll('select');
    M.FormSelect.init(selectElems);
    
    // Initialize datepickers
    var datepickerElems = document.querySelectorAll('.datepicker');
    M.Datepicker.init(datepickerElems);
    
    // Initialize timepickers
    var timepickerElems = document.querySelectorAll('.timepicker');
    M.Timepicker.init(timepickerElems);
}

function initializeAIFeatures() {
    // AI Loading animations
    initializeAILoadingAnimations();
    
    // AI Particles
    initializeAIParticles();
    
    // AI Chat functionality
    initializeAIChat();
    
    // AI Voice commands (if supported)
    initializeVoiceCommands();
}

function initializeAILoadingAnimations() {
    // Add AI-style loading to buttons
    const aiButtons = document.querySelectorAll('.ai-btn');
    
    aiButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (this.classList.contains('loading')) return;
            
            // Add loading state
            this.classList.add('loading');
            const originalText = this.innerHTML;
            
            // Create loading animation
            this.innerHTML = `
                <div class="ai-loading-spinner">
                    <div class="preloader-wrapper small active">
                        <div class="spinner-layer spinner-white-only">
                            <div class="circle-clipper left">
                                <div class="circle"></div>
                            </div>
                            <div class="gap-patch">
                                <div class="circle"></div>
                            </div>
                            <div class="circle-clipper right">
                                <div class="circle"></div>
                            </div>
                        </div>
                    </div>
                    Procesando...
                </div>
            `;
            
            // Remove loading state after delay (if not removed by form submission)
            setTimeout(() => {
                if (this.classList.contains('loading')) {
                    this.classList.remove('loading');
                    this.innerHTML = originalText;
                }
            }, 3000);
        });
    });
}

function initializeAIParticles() {
    // Create floating particles for AI effect
    const particleContainers = document.querySelectorAll('.ai-particles');
    
    particleContainers.forEach(container => {
        createParticles(container);
    });
}

function createParticles(container) {
    const particleCount = 5;
    
    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 4 + 's';
        particle.style.animationDuration = (Math.random() * 3 + 2) + 's';
        container.appendChild(particle);
    }
}

function initializeAIChat() {
    const chatInputs = document.querySelectorAll('#ai-input');
    const sendButtons = document.querySelectorAll('.ai-chat-send');
    
    chatInputs.forEach(input => {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendAIMessage(this);
            }
        });
    });
    
    sendButtons.forEach(button => {
        button.addEventListener('click', function() {
            const input = this.parentElement.querySelector('#ai-input');
            sendAIMessage(input);
        });
    });
}

function sendAIMessage(input) {
    const message = input.value.trim();
    if (!message) return;
    
    const chatContainer = input.closest('.ai-chat-container');
    if (!chatContainer) return;
    
    // Add user message
    addChatMessage(chatContainer, message, 'user');
    
    // Clear input
    input.value = '';
    
    // Show typing indicator
    showTypingIndicator(chatContainer);
    
    // Simulate AI response
    setTimeout(() => {
        hideTypingIndicator(chatContainer);
        const aiResponse = generateAIResponse(message);
        addChatMessage(chatContainer, aiResponse, 'ai');
    }, 1500 + Math.random() * 1000);
}

function addChatMessage(container, message, type) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `ai-message ${type === 'user' ? 'user-message' : ''}`;
    
    const timestamp = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    
    if (type === 'user') {
        messageDiv.innerHTML = `
            <div class="ai-message-content">
                <p>${escapeHtml(message)}</p>
                <small class="grey-text">${timestamp}</small>
            </div>
        `;
    } else {
        messageDiv.innerHTML = `
            <div class="ai-avatar-small">
                <i class="material-icons">smart_toy</i>
            </div>
            <div class="ai-message-content">
                <p>${escapeHtml(message)}</p>
                <small class="grey-text">${timestamp}</small>
            </div>
        `;
    }
    
    const inputField = container.querySelector('.input-field');
    container.insertBefore(messageDiv, inputField);
    
    // Scroll to bottom
    container.scrollTop = container.scrollHeight;
}

function showTypingIndicator(container) {
    const typingDiv = document.createElement('div');
    typingDiv.className = 'ai-message typing-indicator';
    typingDiv.innerHTML = `
        <div class="ai-avatar-small">
            <i class="material-icons">smart_toy</i>
        </div>
        <div class="ai-message-content">
            <div class="typing-dots">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    `;
    
    const inputField = container.querySelector('.input-field');
    container.insertBefore(typingDiv, inputField);
    container.scrollTop = container.scrollHeight;
}

function hideTypingIndicator(container) {
    const typingIndicator = container.querySelector('.typing-indicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

function generateAIResponse(userMessage) {
    const responses = [
        "Entiendo tu consulta. Estoy procesando la información para darte la mejor respuesta posible.",
        "Basándome en los datos disponibles, puedo sugerir las siguientes opciones para optimizar tu gestión.",
        "He analizado tu solicitud usando algoritmos de aprendizaje automático. Aquí tienes mi recomendación:",
        "Perfecto. Mi sistema de IA ha identificado patrones relevantes para tu consulta.",
        "Excelente pregunta. Permíteme procesar esta información con mis algoritmos avanzados.",
        "Gracias por tu consulta. Estoy utilizando procesamiento de lenguaje natural para entender mejor tu necesidad."
    ];
    
    // Simple keyword-based responses
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('ayuda') || lowerMessage.includes('help')) {
        return "¡Por supuesto! Estoy aquí para ayudarte. Puedo asistirte con análisis de datos, gestión de inventario, reportes y mucho más. ¿En qué área específica necesitas ayuda?";
    }
    
    if (lowerMessage.includes('datos') || lowerMessage.includes('data')) {
        return "Los datos son el corazón de INVERTORIA. Puedo ayudarte a analizar, procesar y extraer insights valiosos de tu información. ¿Qué tipo de análisis necesitas?";
    }
    
    if (lowerMessage.includes('reporte') || lowerMessage.includes('report')) {
        return "Puedo generar reportes detallados y visualizaciones interactivas. ¿Te gustaría un reporte de rendimiento, análisis de tendencias o algo específico?";
    }
    
    if (lowerMessage.includes('inventario') || lowerMessage.includes('inventory')) {
        return "El sistema de inventario inteligente puede optimizar tus stocks, predecir demanda y alertarte sobre reposiciones. ¿Necesitas ayuda con algún aspecto específico?";
    }
    
    // Default response
    return responses[Math.floor(Math.random() * responses.length)];
}

function initializeVoiceCommands() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        return; // Speech recognition not supported
    }
    
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'es-ES';
    
    // Add voice command button if AI chat exists
    const aiChatContainers = document.querySelectorAll('.ai-chat-container');
    aiChatContainers.forEach(container => {
        const inputField = container.querySelector('.input-field');
        if (inputField) {
            const voiceButton = document.createElement('button');
            voiceButton.className = 'btn-floating btn-small ai-btn voice-btn';
            voiceButton.innerHTML = '<i class="material-icons">mic</i>';
            voiceButton.style.marginLeft = '10px';
            
            voiceButton.addEventListener('click', function() {
                startVoiceRecognition(recognition, container);
            });
            
            inputField.appendChild(voiceButton);
        }
    });
}

function startVoiceRecognition(recognition, container) {
    const voiceBtn = container.querySelector('.voice-btn');
    const input = container.querySelector('#ai-input');
    
    voiceBtn.innerHTML = '<i class="material-icons">mic_off</i>';
    voiceBtn.classList.add('red');
    
    recognition.start();
    
    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        input.value = transcript;
        sendAIMessage(input);
    };
    
    recognition.onend = function() {
        voiceBtn.innerHTML = '<i class="material-icons">mic</i>';
        voiceBtn.classList.remove('red');
    };
    
    recognition.onerror = function(event) {
        console.error('Speech recognition error:', event.error);
        voiceBtn.innerHTML = '<i class="material-icons">mic</i>';
        voiceBtn.classList.remove('red');
        M.toast({html: 'Error en el reconocimiento de voz', classes: 'red'});
    };
}

function initializeFormValidations() {
    // Real-time email validation
    const emailInputs = document.querySelectorAll('input[type="email"]');
    emailInputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateEmail(this);
        });
        
        input.addEventListener('input', function() {
            if (this.value.length > 0) {
                validateEmail(this);
            }
        });
    });
    
    // Password strength validation
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    passwordInputs.forEach(input => {
        if (input.name === 'password' || input.id === 'password') {
            input.addEventListener('input', function() {
                validatePasswordStrength(this);
            });
        }
    });
    
    // Confirm password validation
    const confirmPasswordInputs = document.querySelectorAll('input[name="confirm_password"]');
    confirmPasswordInputs.forEach(input => {
        input.addEventListener('input', function() {
            validatePasswordConfirmation(this);
        });
    });
}

function validateEmail(input) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const isValid = emailRegex.test(input.value);
    
    if (input.value.length === 0) {
        input.classList.remove('valid', 'invalid');
        return;
    }
    
    if (isValid) {
        input.classList.add('valid');
        input.classList.remove('invalid');
    } else {
        input.classList.add('invalid');
        input.classList.remove('valid');
    }
}

function validatePasswordStrength(input) {
    const password = input.value;
    const minLength = 6;
    
    // Create or update password strength indicator
    let strengthIndicator = input.parentElement.querySelector('.password-strength');
    if (!strengthIndicator) {
        strengthIndicator = document.createElement('div');
        strengthIndicator.className = 'password-strength';
        input.parentElement.appendChild(strengthIndicator);
    }
    
    if (password.length === 0) {
        strengthIndicator.innerHTML = '';
        input.classList.remove('valid', 'invalid');
        return;
    }
    
    let strength = 0;
    let feedback = [];
    
    // Length check
    if (password.length >= minLength) {
        strength += 1;
    } else {
        feedback.push(`Mínimo ${minLength} caracteres`);
    }
    
    // Uppercase check
    if (/[A-Z]/.test(password)) {
        strength += 1;
    } else {
        feedback.push('Una mayúscula');
    }
    
    // Lowercase check
    if (/[a-z]/.test(password)) {
        strength += 1;
    } else {
        feedback.push('Una minúscula');
    }
    
    // Number check
    if (/\d/.test(password)) {
        strength += 1;
    } else {
        feedback.push('Un número');
    }
    
    // Special character check
    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        strength += 1;
    } else {
        feedback.push('Un carácter especial');
    }
    
    // Update UI based on strength
    const strengthLevels = ['Muy débil', 'Débil', 'Regular', 'Buena', 'Fuerte'];
    const strengthColors = ['red', 'orange', 'yellow', 'light-green', 'green'];
    
    const strengthLevel = Math.min(strength, 4);
    const strengthText = strengthLevels[strengthLevel];
    const strengthColor = strengthColors[strengthLevel];
    
    strengthIndicator.innerHTML = `
        <div class="password-strength-bar">
            <div class="strength-fill ${strengthColor}" style="width: ${(strengthLevel + 1) * 20}%"></div>
        </div>
        <small class="${strengthColor}-text">Fortaleza: ${strengthText}</small>
    `;
    
    if (feedback.length > 0 && password.length > 0) {
        strengthIndicator.innerHTML += `<small class="grey-text"><br>Falta: ${feedback.join(', ')}</small>`;
    }
    
    // Mark as valid/invalid
    if (strength >= 2) {
        input.classList.add('valid');
        input.classList.remove('invalid');
    } else {
        input.classList.add('invalid');
        input.classList.remove('valid');
    }
}

function validatePasswordConfirmation(input) {
    const password = document.querySelector('input[name="password"]').value;
    const confirmPassword = input.value;
    
    if (confirmPassword.length === 0) {
        input.classList.remove('valid', 'invalid');
        return;
    }
    
    if (password === confirmPassword) {
        input.classList.add('valid');
        input.classList.remove('invalid');
    } else {
        input.classList.add('invalid');
        input.classList.remove('valid');
    }
}

function initializeSecurityFeatures() {
    // Token validation
    validateTokenPeriodically();
    
    // Session timeout warning
    initializeSessionTimeout();
    
    // CSRF protection
    addCSRFTokens();
    
    // Secure form submissions
    secureFormSubmissions();
}

function validateTokenPeriodically() {
    // Check token validity every 5 minutes
    setInterval(function() {
        const token = getStoredToken();
        if (token) {
            validateToken(token);
        }
    }, 5 * 60 * 1000);
}

function getStoredToken() {
    // In this implementation, token is stored in session (server-side)
    // This is just for client-side validation if needed
    return localStorage.getItem('access_token') || sessionStorage.getItem('access_token');
}

function validateToken(token) {
    fetch('/api/validate-token', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ token: token })
    })
    .then(response => response.json())
    .then(data => {
        if (!data.valid) {
            handleInvalidToken(data.message);
        }
    })
    .catch(error => {
        console.error('Token validation error:', error);
    });
}

function handleInvalidToken(message) {
    M.toast({
        html: `Sesión expirada: ${message}. Redirigiendo al login...`,
        classes: 'red',
        displayLength: 3000
    });
    
    setTimeout(() => {
        window.location.href = '/login';
    }, 3000);
}

function initializeSessionTimeout() {
    let sessionTimeout;
    const timeoutDuration = 30 * 60 * 1000; // 30 minutes
    
    function resetSessionTimeout() {
        clearTimeout(sessionTimeout);
        sessionTimeout = setTimeout(() => {
            showSessionTimeoutWarning();
        }, timeoutDuration - 5 * 60 * 1000); // Warn 5 minutes before timeout
    }
    
    function showSessionTimeoutWarning() {
        const toast = M.toast({
            html: `
                <span>Tu sesión expirará en 5 minutos.</span>
                <button class="btn-flat toast-action" onclick="extendSession()">Extender</button>
            `,
            classes: 'orange',
            displayLength: 60000
        });
        
        // Auto-logout after 5 minutes if no action
        setTimeout(() => {
            window.location.href = '/logout';
        }, 5 * 60 * 1000);
    }
    
    // Reset timeout on user activity
    ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'].forEach(event => {
        document.addEventListener(event, resetSessionTimeout, true);
    });
    
    // Initialize timeout
    resetSessionTimeout();
}

function extendSession() {
    // Make a request to extend the session
    fetch('/api/extend-session', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => {
        if (response.ok) {
            M.toast({html: 'Sesión extendida exitosamente', classes: 'green'});
        }
    })
    .catch(error => {
        console.error('Session extension error:', error);
    });
}

function addCSRFTokens() {
    // Add CSRF tokens to all forms
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        if (!form.querySelector('input[name="csrf_token"]')) {
            const csrfToken = document.createElement('input');
            csrfToken.type = 'hidden';
            csrfToken.name = 'csrf_token';
            csrfToken.value = generateCSRFToken();
            form.appendChild(csrfToken);
        }
    });
}

function generateCSRFToken() {
    // Simple CSRF token generation (in production, use server-generated tokens)
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

function secureFormSubmissions() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            // Add security headers and validation
            const formData = new FormData(this);
            
            // Validate required fields
            const requiredFields = this.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.classList.add('invalid');
                    isValid = false;
                } else {
                    field.classList.remove('invalid');
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                M.toast({html: 'Por favor completa todos los campos requeridos', classes: 'red'});
                return;
            }
            
            // Add timestamp for replay attack prevention
            const timestamp = document.createElement('input');
            timestamp.type = 'hidden';
            timestamp.name = 'timestamp';
            timestamp.value = Date.now();
            this.appendChild(timestamp);
        });
    });
}

// Utility functions
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

function debounce(func, wait, immediate) {
    let timeout;
    return function executedFunction() {
        const context = this;
        const args = arguments;
        const later = function() {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}

// Global error handler
window.addEventListener('error', function(e) {
    console.error('Global error:', e.error);
    
    // Don't show error toast for network errors or script loading errors
    if (e.error && e.error.name !== 'NetworkError' && !e.filename) {
        M.toast({
            html: 'Ha ocurrido un error inesperado. Por favor recarga la página.',
            classes: 'red',
            displayLength: 5000
        });
    }
});

// Service Worker registration (for PWA capabilities)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/static/sw.js')
            .then(function(registration) {
                console.log('ServiceWorker registration successful');
            })
            .catch(function(err) {
                console.log('ServiceWorker registration failed');
            });
    });
}

// Export functions for global use
window.INVERTORIA = {
    validateEmail,
    validatePasswordStrength,
    validatePasswordConfirmation,
    sendAIMessage,
    escapeHtml,
    debounce,
    throttle
};