from pymongo import MongoClient
from pymongo.database import Database
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)

class DatabaseConnection:
    """Singleton pattern for MongoDB connection"""
    _instance = None
    _client = None
    _database = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(DatabaseConnection, cls).__new__(cls)
        return cls._instance

    def connect(self) -> Database:
        """Connect to MongoDB and return database instance"""
        if self._database is None:
            try:
                self._client = MongoClient(settings.MONGODB_URL)
                self._database = self._client[settings.DATABASE_NAME]
                
                # Test connection
                self._client.admin.command('ping')
                logger.info(f"Connected to MongoDB: {settings.DATABASE_NAME}")
                
            except Exception as e:
                logger.error(f"Failed to connect to MongoDB: {e}")
                raise e
        
        return self._database

    def close(self):
        """Close MongoDB connection"""
        if self._client:
            self._client.close()
            self._client = None
            self._database = None
            logger.info("MongoDB connection closed")

    def get_database(self) -> Database:
        """Get database instance"""
        if self._database is None:
            return self.connect()
        return self._database

# Global database instance
db_connection = DatabaseConnection()

def get_database() -> Database:
    """Dependency to get database instance"""
    return db_connection.get_database()