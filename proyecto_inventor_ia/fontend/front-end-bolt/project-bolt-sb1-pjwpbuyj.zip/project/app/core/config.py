from decouple import config

class Settings:
    # Database
    MONGODB_URL: str = config("MONGODB_URL", default="mongodb://localhost:27017")
    DATABASE_NAME: str = config("DATABASE_NAME", default="fastapi_auth_db")
    
    # JWT
    SECRET_KEY: str = config("SECRET_KEY", default="your-secret-key-here")
    ALGORITHM: str = config("ALGORITHM", default="HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = config("ACCESS_TOKEN_EXPIRE_MINUTES", default=30, cast=int)
    
    # Admin user
    ADMIN_EMAIL: str = config("ADMIN_EMAIL", default="admin@example.com")
    ADMIN_PASSWORD: str = config("ADMIN_PASSWORD", default="admin123")

settings = Settings()