from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from pymongo.database import Database
from app.core.database import get_database
from app.services.role_service import RoleService
from app.models.role import Role, RoleCreate, RoleUpdate, RoleWithPermissions
from app.models.user import User
from app.api.dependencies import require_permission

router = APIRouter()

@router.post("/", response_model=Role)
async def create_role(
    role: RoleCreate,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("roles", "create"))
):
    """Create new role (requires permission)"""
    role_service = RoleService(db)
    
    try:
        db_role = role_service.create_role(role)
        role_dict = db_role.dict()
        role_dict["id"] = str(role_dict.pop("_id"))
        return Role(**role_dict)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/", response_model=List[Role])
async def read_roles(
    skip: int = 0,
    limit: int = 100,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("roles", "read"))
):
    """Get all roles (requires permission)"""
    role_service = RoleService(db)
    return role_service.get_roles(skip=skip, limit=limit)

@router.get("/{role_id}", response_model=RoleWithPermissions)
async def read_role(
    role_id: str,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("roles", "read"))
):
    """Get role by ID with permissions (requires permission)"""
    role_service = RoleService(db)
    role = role_service.get_role_with_permissions(role_id)
    
    if role is None:
        raise HTTPException(status_code=404, detail="Role not found")
    
    return role

@router.put("/{role_id}", response_model=Role)
async def update_role(
    role_id: str,
    role_update: RoleUpdate,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("roles", "update"))
):
    """Update role (requires permission)"""
    role_service = RoleService(db)
    role = role_service.update_role(role_id, role_update)
    
    if role is None:
        raise HTTPException(status_code=404, detail="Role not found")
    
    role_dict = role.dict()
    role_dict["id"] = str(role_dict.pop("_id"))
    return Role(**role_dict)

@router.delete("/{role_id}")
async def delete_role(
    role_id: str,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("roles", "delete"))
):
    """Delete role (requires permission)"""
    role_service = RoleService(db)
    success = role_service.delete_role(role_id)
    
    if not success:
        raise HTTPException(status_code=404, detail="Role not found")
    
    return {"message": "Role deleted successfully"}