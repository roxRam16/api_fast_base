from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from pymongo.database import Database
from app.core.database import get_database
from app.services.user_service import UserService
from app.models.user import User, UserCreate, UserUpdate, UserWithRoles
from app.api.dependencies import require_permission

router = APIRouter()

@router.post("/", response_model=User)
async def create_user(
    user: UserCreate,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("users", "create"))
):
    """Create new user (requires permission)"""
    user_service = UserService(db)
    
    try:
        db_user = user_service.create_user(user)
        user_dict = db_user.dict()
        user_dict["id"] = str(user_dict.pop("_id"))
        user_dict.pop("hashed_password")
        return User(**user_dict)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/", response_model=List[User])
async def read_users(
    skip: int = 0,
    limit: int = 100,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("users", "read"))
):
    """Get all users (requires permission)"""
    user_service = UserService(db)
    return user_service.get_users(skip=skip, limit=limit)

@router.get("/{user_id}", response_model=UserWithRoles)
async def read_user(
    user_id: str,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("users", "read"))
):
    """Get user by ID with roles (requires permission)"""
    user_service = UserService(db)
    user = user_service.get_user_with_roles(user_id)
    
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    
    return user

@router.put("/{user_id}", response_model=User)
async def update_user(
    user_id: str,
    user_update: UserUpdate,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("users", "update"))
):
    """Update user (requires permission)"""
    user_service = UserService(db)
    user = user_service.update_user(user_id, user_update)
    
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    
    user_dict = user.dict()
    user_dict["id"] = str(user_dict.pop("_id"))
    user_dict.pop("hashed_password")
    return User(**user_dict)

@router.delete("/{user_id}")
async def delete_user(
    user_id: str,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("users", "delete"))
):
    """Delete user (requires permission)"""
    user_service = UserService(db)
    success = user_service.delete_user(user_id)
    
    if not success:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {"message": "User deleted successfully"}