from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from pymongo.database import Database
from app.core.database import get_database
from app.services.permission_service import PermissionService
from app.models.permission import Permission, PermissionCreate, PermissionUpdate
from app.models.user import User
from app.api.dependencies import require_permission

router = APIRouter()

@router.post("/", response_model=Permission)
async def create_permission(
    permission: PermissionCreate,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("permissions", "create"))
):
    """Create new permission (requires permission)"""
    permission_service = PermissionService(db)
    
    try:
        db_permission = permission_service.create_permission(permission)
        permission_dict = db_permission.dict()
        permission_dict["id"] = str(permission_dict.pop("_id"))
        return Permission(**permission_dict)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/", response_model=List[Permission])
async def read_permissions(
    skip: int = 0,
    limit: int = 100,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("permissions", "read"))
):
    """Get all permissions (requires permission)"""
    permission_service = PermissionService(db)
    return permission_service.get_permissions(skip=skip, limit=limit)

@router.get("/{permission_id}", response_model=Permission)
async def read_permission(
    permission_id: str,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("permissions", "read"))
):
    """Get permission by ID (requires permission)"""
    permission_service = PermissionService(db)
    permission = permission_service.get_permission_by_id(permission_id)
    
    if permission is None:
        raise HTTPException(status_code=404, detail="Permission not found")
    
    permission_dict = permission.dict()
    permission_dict["id"] = str(permission_dict.pop("_id"))
    return Permission(**permission_dict)

@router.put("/{permission_id}", response_model=Permission)
async def update_permission(
    permission_id: str,
    permission_update: PermissionUpdate,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("permissions", "update"))
):
    """Update permission (requires permission)"""
    permission_service = PermissionService(db)
    permission = permission_service.update_permission(permission_id, permission_update)
    
    if permission is None:
        raise HTTPException(status_code=404, detail="Permission not found")
    
    permission_dict = permission.dict()
    permission_dict["id"] = str(permission_dict.pop("_id"))
    return Permission(**permission_dict)

@router.delete("/{permission_id}")
async def delete_permission(
    permission_id: str,
    db: Database = Depends(get_database),
    _: User = Depends(require_permission("permissions", "delete"))
):
    """Delete permission (requires permission)"""
    permission_service = PermissionService(db)
    success = permission_service.delete_permission(permission_id)
    
    if not success:
        raise HTTPException(status_code=404, detail="Permission not found")
    
    return {"message": "Permission deleted successfully"}