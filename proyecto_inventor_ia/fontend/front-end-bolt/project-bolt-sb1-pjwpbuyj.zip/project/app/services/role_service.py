from typing import Optional, List
from pymongo.database import Database
from bson import ObjectId
from datetime import datetime
from app.models.role import RoleCreate, RoleUpdate, RoleInDB, Role, RoleWithPermissions
from app.services.permission_service import PermissionService

class RoleService:
    def __init__(self, db: Database):
        self.db = db
        self.collection = db.roles
        self.permission_service = PermissionService(db)

    def create_role(self, role: RoleCreate) -> RoleInDB:
        """Create a new role"""
        # Check if role already exists
        if self.get_role_by_name(role.name):
            raise ValueError("Role with this name already exists")
        
        # Create role document
        role_dict = role.dict()
        role_dict["created_at"] = datetime.utcnow()
        role_dict["updated_at"] = datetime.utcnow()
        
        # Insert role
        result = self.collection.insert_one(role_dict)
        role_dict["_id"] = result.inserted_id
        
        return RoleInDB(**role_dict)

    def get_role_by_id(self, role_id: str) -> Optional[RoleInDB]:
        """Get role by ID"""
        if not ObjectId.is_valid(role_id):
            return None
        
        role_doc = self.collection.find_one({"_id": ObjectId(role_id)})
        if role_doc:
            return RoleInDB(**role_doc)
        return None

    def get_role_by_name(self, name: str) -> Optional[RoleInDB]:
        """Get role by name"""
        role_doc = self.collection.find_one({"name": name})
        if role_doc:
            return RoleInDB(**role_doc)
        return None

    def get_roles(self, skip: int = 0, limit: int = 100) -> List[Role]:
        """Get all roles with pagination"""
        cursor = self.collection.find().skip(skip).limit(limit)
        roles = []
        for role_doc in cursor:
            role_dict = role_doc.copy()
            role_dict["id"] = str(role_dict.pop("_id"))
            roles.append(Role(**role_dict))
        return roles

    def update_role(self, role_id: str, role_update: RoleUpdate) -> Optional[RoleInDB]:
        """Update role"""
        if not ObjectId.is_valid(role_id):
            return None
        
        update_data = role_update.dict(exclude_unset=True)
        if update_data:
            update_data["updated_at"] = datetime.utcnow()
            
            result = self.collection.update_one(
                {"_id": ObjectId(role_id)},
                {"$set": update_data}
            )
            
            if result.modified_count:
                return self.get_role_by_id(role_id)
        
        return None

    def delete_role(self, role_id: str) -> bool:
        """Delete role"""
        if not ObjectId.is_valid(role_id):
            return False
        
        result = self.collection.delete_one({"_id": ObjectId(role_id)})
        return result.deleted_count > 0

    def get_role_with_permissions(self, role_id: str) -> Optional[RoleWithPermissions]:
        """Get role with its permissions"""
        role = self.get_role_by_id(role_id)
        if not role:
            return None
        
        # Convert to Role model first
        role_dict = role.dict()
        role_dict["id"] = str(role_dict.pop("_id"))
        
        # Get permissions
        permissions = []
        for permission_id in role.permission_ids:
            permission = self.permission_service.get_permission_by_id(permission_id)
            if permission:
                permission_dict = permission.dict()
                permission_dict["id"] = str(permission_dict.pop("_id"))
                permissions.append(permission_dict)
        
        role_dict["permissions"] = permissions
        return RoleWithPermissions(**role_dict)