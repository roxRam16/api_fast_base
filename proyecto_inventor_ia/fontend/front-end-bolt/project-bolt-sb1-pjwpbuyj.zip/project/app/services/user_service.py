from typing import Optional, List
from pymongo.database import Database
from bson import ObjectId
from datetime import datetime
from app.models.user import UserCreate, UserUpdate, UserInDB, User, UserWithRoles
from app.core.security import get_password_hash, verify_password
from app.services.role_service import RoleService

class UserService:
    def __init__(self, db: Database):
        self.db = db
        self.collection = db.users
        self.role_service = RoleService(db)

    def create_user(self, user: UserCreate) -> UserInDB:
        """Create a new user"""
        # Check if user already exists
        if self.get_user_by_email(user.email):
            raise ValueError("User with this email already exists")
        
        # Hash password
        hashed_password = get_password_hash(user.password)
        
        # Create user document
        user_dict = user.dict(exclude={"password"})
        user_dict["hashed_password"] = hashed_password
        user_dict["created_at"] = datetime.utcnow()
        user_dict["updated_at"] = datetime.utcnow()
        
        # Insert user
        result = self.collection.insert_one(user_dict)
        user_dict["_id"] = result.inserted_id
        
        return UserInDB(**user_dict)

    def get_user_by_id(self, user_id: str) -> Optional[UserInDB]:
        """Get user by ID"""
        if not ObjectId.is_valid(user_id):
            return None
        
        user_doc = self.collection.find_one({"_id": ObjectId(user_id)})
        if user_doc:
            return UserInDB(**user_doc)
        return None

    def get_user_by_email(self, email: str) -> Optional[UserInDB]:
        """Get user by email"""
        user_doc = self.collection.find_one({"email": email})
        if user_doc:
            return UserInDB(**user_doc)
        return None

    def get_users(self, skip: int = 0, limit: int = 100) -> List[User]:
        """Get all users with pagination"""
        cursor = self.collection.find().skip(skip).limit(limit)
        users = []
        for user_doc in cursor:
            user_dict = user_doc.copy()
            user_dict["id"] = str(user_dict.pop("_id"))
            users.append(User(**user_dict))
        return users

    def update_user(self, user_id: str, user_update: UserUpdate) -> Optional[UserInDB]:
        """Update user"""
        if not ObjectId.is_valid(user_id):
            return None
        
        update_data = user_update.dict(exclude_unset=True)
        if update_data:
            update_data["updated_at"] = datetime.utcnow()
            
            result = self.collection.update_one(
                {"_id": ObjectId(user_id)},
                {"$set": update_data}
            )
            
            if result.modified_count:
                return self.get_user_by_id(user_id)
        
        return None

    def delete_user(self, user_id: str) -> bool:
        """Delete user"""
        if not ObjectId.is_valid(user_id):
            return False
        
        result = self.collection.delete_one({"_id": ObjectId(user_id)})
        return result.deleted_count > 0

    def authenticate_user(self, email: str, password: str) -> Optional[UserInDB]:
        """Authenticate user with email and password"""
        user = self.get_user_by_email(email)
        if not user:
            return None
        if not verify_password(password, user.hashed_password):
            return None
        return user

    def get_user_with_roles(self, user_id: str) -> Optional[UserWithRoles]:
        """Get user with their roles"""
        user = self.get_user_by_id(user_id)
        if not user:
            return None
        
        # Convert to User model first
        user_dict = user.dict()
        user_dict["id"] = str(user_dict.pop("_id"))
        user_dict.pop("hashed_password")
        
        # Get roles
        roles = []
        for role_id in user.role_ids:
            role = self.role_service.get_role_by_id(role_id)
            if role:
                role_dict = role.dict()
                role_dict["id"] = str(role_dict.pop("_id"))
                roles.append(role_dict)
        
        user_dict["roles"] = roles
        return UserWithRoles(**user_dict)

    def user_has_permission(self, user_id: str, resource: str, action: str) -> bool:
        """Check if user has specific permission"""
        user_with_roles = self.get_user_with_roles(user_id)
        if not user_with_roles:
            return False
        
        for role in user_with_roles.roles:
            role_with_permissions = self.role_service.get_role_with_permissions(role["id"])
            if role_with_permissions:
                for permission in role_with_permissions.permissions:
                    if permission["resource"] == resource and permission["action"] == action:
                        return True
        
        return False