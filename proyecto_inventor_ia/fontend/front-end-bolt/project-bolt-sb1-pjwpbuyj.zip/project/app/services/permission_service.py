from typing import Optional, List
from pymongo.database import Database
from bson import ObjectId
from datetime import datetime
from app.models.permission import PermissionCreate, PermissionUpdate, PermissionInDB, Permission

class PermissionService:
    def __init__(self, db: Database):
        self.db = db
        self.collection = db.permissions

    def create_permission(self, permission: PermissionCreate) -> PermissionInDB:
        """Create a new permission"""
        # Check if permission already exists
        if self.get_permission_by_name(permission.name):
            raise ValueError("Permission with this name already exists")
        
        # Create permission document
        permission_dict = permission.dict()
        permission_dict["created_at"] = datetime.utcnow()
        permission_dict["updated_at"] = datetime.utcnow()
        
        # Insert permission
        result = self.collection.insert_one(permission_dict)
        permission_dict["_id"] = result.inserted_id
        
        return PermissionInDB(**permission_dict)

    def get_permission_by_id(self, permission_id: str) -> Optional[PermissionInDB]:
        """Get permission by ID"""
        if not ObjectId.is_valid(permission_id):
            return None
        
        permission_doc = self.collection.find_one({"_id": ObjectId(permission_id)})
        if permission_doc:
            return PermissionInDB(**permission_doc)
        return None

    def get_permission_by_name(self, name: str) -> Optional[PermissionInDB]:
        """Get permission by name"""
        permission_doc = self.collection.find_one({"name": name})
        if permission_doc:
            return PermissionInDB(**permission_doc)
        return None

    def get_permissions(self, skip: int = 0, limit: int = 100) -> List[Permission]:
        """Get all permissions with pagination"""
        cursor = self.collection.find().skip(skip).limit(limit)
        permissions = []
        for permission_doc in cursor:
            permission_dict = permission_doc.copy()
            permission_dict["id"] = str(permission_dict.pop("_id"))
            permissions.append(Permission(**permission_dict))
        return permissions

    def update_permission(self, permission_id: str, permission_update: PermissionUpdate) -> Optional[PermissionInDB]:
        """Update permission"""
        if not ObjectId.is_valid(permission_id):
            return None
        
        update_data = permission_update.dict(exclude_unset=True)
        if update_data:
            update_data["updated_at"] = datetime.utcnow()
            
            result = self.collection.update_one(
                {"_id": ObjectId(permission_id)},
                {"$set": update_data}
            )
            
            if result.modified_count:
                return self.get_permission_by_id(permission_id)
        
        return None

    def delete_permission(self, permission_id: str) -> bool:
        """Delete permission"""
        if not ObjectId.is_valid(permission_id):
            return False
        
        result = self.collection.delete_one({"_id": ObjectId(permission_id)})
        return result.deleted_count > 0

    def get_permissions_by_resource_action(self, resource: str, action: str) -> List[Permission]:
        """Get permissions by resource and action"""
        cursor = self.collection.find({"resource": resource, "action": action})
        permissions = []
        for permission_doc in cursor:
            permission_dict = permission_doc.copy()
            permission_dict["id"] = str(permission_dict.pop("_id"))
            permissions.append(Permission(**permission_dict))
        return permissions