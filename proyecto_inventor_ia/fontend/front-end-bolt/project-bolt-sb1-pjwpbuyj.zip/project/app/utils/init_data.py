from pymongo.database import Database
from app.services.user_service import UserService
from app.services.role_service import RoleService
from app.services.permission_service import PermissionService
from app.models.user import UserCreate
from app.models.role import RoleCreate
from app.models.permission import PermissionCreate
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)

def create_initial_permissions(db: Database):
    """Create initial permissions"""
    permission_service = PermissionService(db)
    
    # Define initial permissions
    permissions_data = [
        # User permissions
        {"name": "Create Users", "description": "Create new users", "resource": "users", "action": "create"},
        {"name": "Read Users", "description": "View users", "resource": "users", "action": "read"},
        {"name": "Update Users", "description": "Update users", "resource": "users", "action": "update"},
        {"name": "Delete Users", "description": "Delete users", "resource": "users", "action": "delete"},
        
        # Role permissions
        {"name": "Create Roles", "description": "Create new roles", "resource": "roles", "action": "create"},
        {"name": "Read Roles", "description": "View roles", "resource": "roles", "action": "read"},
        {"name": "Update Roles", "description": "Update roles", "resource": "roles", "action": "update"},
        {"name": "Delete Roles", "description": "Delete roles", "resource": "roles", "action": "delete"},
        
        # Permission permissions
        {"name": "Create Permissions", "description": "Create new permissions", "resource": "permissions", "action": "create"},
        {"name": "Read Permissions", "description": "View permissions", "resource": "permissions", "action": "read"},
        {"name": "Update Permissions", "description": "Update permissions", "resource": "permissions", "action": "update"},
        {"name": "Delete Permissions", "description": "Delete permissions", "resource": "permissions", "action": "delete"},
    ]
    
    created_permissions = []
    for perm_data in permissions_data:
        try:
            existing_permission = permission_service.get_permission_by_name(perm_data["name"])
            if not existing_permission:
                permission = PermissionCreate(**perm_data)
                created_permission = permission_service.create_permission(permission)
                created_permissions.append(str(created_permission.id))
                logger.info(f"Created permission: {perm_data['name']}")
            else:
                created_permissions.append(str(existing_permission.id))
                logger.info(f"Permission already exists: {perm_data['name']}")
        except Exception as e:
            logger.error(f"Error creating permission {perm_data['name']}: {e}")
    
    return created_permissions

def create_initial_roles(db: Database, permission_ids: list):
    """Create initial roles"""
    role_service = RoleService(db)
    
    # Create admin role with all permissions
    try:
        existing_admin_role = role_service.get_role_by_name("Admin")
        if not existing_admin_role:
            admin_role = RoleCreate(
                name="Admin",
                description="Administrator with full access",
                permission_ids=permission_ids
            )
            created_admin_role = role_service.create_role(admin_role)
            logger.info("Created Admin role")
            return str(created_admin_role.id)
        else:
            logger.info("Admin role already exists")
            return str(existing_admin_role.id)
    except Exception as e:
        logger.error(f"Error creating Admin role: {e}")
        return None

def create_initial_admin_user(db: Database, admin_role_id: str):
    """Create initial admin user"""
    user_service = UserService(db)
    
    try:
        existing_admin = user_service.get_user_by_email(settings.ADMIN_EMAIL)
        if not existing_admin:
            admin_user = UserCreate(
                email=settings.ADMIN_EMAIL,
                password=settings.ADMIN_PASSWORD,
                full_name="System Administrator",
                role_ids=[admin_role_id] if admin_role_id else []
            )
            created_admin = user_service.create_user(admin_user)
            logger.info(f"Created admin user: {settings.ADMIN_EMAIL}")
            return created_admin
        else:
            logger.info(f"Admin user already exists: {settings.ADMIN_EMAIL}")
            return existing_admin
    except Exception as e:
        logger.error(f"Error creating admin user: {e}")
        return None

def initialize_database(db: Database):
    """Initialize database with default data"""
    logger.info("Initializing database with default data...")
    
    # Create permissions
    permission_ids = create_initial_permissions(db)
    
    # Create admin role
    admin_role_id = create_initial_roles(db, permission_ids)
    
    # Create admin user
    if admin_role_id:
        create_initial_admin_user(db, admin_role_id)
    
    logger.info("Database initialization completed")