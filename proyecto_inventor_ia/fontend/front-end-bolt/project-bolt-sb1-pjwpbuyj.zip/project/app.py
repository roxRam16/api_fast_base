from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import requests
import os
from datetime import datetime, timedelta
import jwt
from functools import wraps
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'your-secret-key-change-in-production')

# API Configuration
API_BASE_URL = os.environ.get('API_BASE_URL', 'http://localhost:8000/api')
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key-here')
JWT_ALGORITHM = os.environ.get('JWT_ALGORITHM', 'HS256')

def login_required(f):
    """Decorator to require login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'access_token' not in session:
            flash('Por favor inicia sesión para acceder a esta página.', 'warning')
            return redirect(url_for('login'))
        
        # Verify token is still valid
        try:
            token = session['access_token']
            payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
            # Token is valid, continue
        except jwt.ExpiredSignatureError:
            flash('Tu sesión ha expirado. Por favor inicia sesión nuevamente.', 'warning')
            session.clear()
            return redirect(url_for('login'))
        except jwt.InvalidTokenError:
            flash('Token inválido. Por favor inicia sesión nuevamente.', 'error')
            session.clear()
            return redirect(url_for('login'))
        
        return f(*args, **kwargs)
    return decorated_function

def make_api_request(endpoint, method='GET', data=None, token=None):
    """Make API request with error handling"""
    url = f"{API_BASE_URL}{endpoint}"
    headers = {'Content-Type': 'application/json'}
    
    if token:
        headers['Authorization'] = f'Bearer {token}'
    
    try:
        if method == 'POST':
            if 'login' in endpoint:
                # For login, use form data
                headers['Content-Type'] = 'application/x-www-form-urlencoded'
                response = requests.post(url, data=data, headers=headers, timeout=10)
            else:
                response = requests.post(url, json=data, headers=headers, timeout=10)
        elif method == 'GET':
            response = requests.get(url, headers=headers, timeout=10)
        elif method == 'PUT':
            response = requests.put(url, json=data, headers=headers, timeout=10)
        elif method == 'DELETE':
            response = requests.delete(url, headers=headers, timeout=10)
        else:
            raise ValueError(f"Unsupported HTTP method: {method}")
        
        return response
    except requests.exceptions.RequestException as e:
        logger.error(f"API request failed: {e}")
        return None

@app.route('/')
def index():
    """Home page"""
    if 'access_token' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        
        # Client-side validation
        if not email or not password:
            flash('Por favor completa todos los campos.', 'error')
            return render_template('login.html')
        
        # Validate email format
        import re
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_pattern, email):
            flash('Por favor ingresa un email válido.', 'error')
            return render_template('login.html')
        
        # Make API request
        login_data = {
            'username': email,
            'password': password
        }
        
        response = make_api_request('/auth/login', method='POST', data=login_data)
        
        if response is None:
            flash('Error de conexión. Por favor intenta nuevamente.', 'error')
            return render_template('login.html')
        
        if response.status_code == 200:
            data = response.json()
            access_token = data.get('access_token')
            
            if access_token:
                # Store token in session
                session['access_token'] = access_token
                session['user_email'] = email
                
                # Get user info
                user_response = make_api_request('/auth/me', token=access_token)
                if user_response and user_response.status_code == 200:
                    user_data = user_response.json()
                    session['user_name'] = user_data.get('full_name', 'Usuario')
                    session['user_id'] = user_data.get('id')
                
                flash(f'¡Bienvenido a INVERTORIA!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Error en la respuesta del servidor.', 'error')
        elif response.status_code == 401:
            flash('Email o contraseña incorrectos.', 'error')
        elif response.status_code == 422:
            flash('Datos de entrada inválidos.', 'error')
        else:
            flash('Error del servidor. Por favor intenta más tarde.', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Register page"""
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        full_name = request.form.get('full_name', '').strip()
        
        # Validation
        errors = []
        
        if not email or not password or not confirm_password or not full_name:
            errors.append('Todos los campos son obligatorios.')
        
        if password != confirm_password:
            errors.append('Las contraseñas no coinciden.')
        
        if len(password) < 6:
            errors.append('La contraseña debe tener al menos 6 caracteres.')
        
        # Validate email format
        import re
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_pattern, email):
            errors.append('Por favor ingresa un email válido.')
        
        if errors:
            for error in errors:
                flash(error, 'error')
            return render_template('register.html')
        
        # Make API request
        register_data = {
            'email': email,
            'password': password,
            'full_name': full_name,
            'role_ids': []
        }
        
        response = make_api_request('/auth/register', method='POST', data=register_data)
        
        if response is None:
            flash('Error de conexión. Por favor intenta nuevamente.', 'error')
            return render_template('register.html')
        
        if response.status_code == 200:
            flash('¡Registro exitoso! Ahora puedes iniciar sesión.', 'success')
            return redirect(url_for('login'))
        elif response.status_code == 400:
            error_detail = response.json().get('detail', 'Error en el registro')
            flash(f'Error: {error_detail}', 'error')
        else:
            flash('Error del servidor. Por favor intenta más tarde.', 'error')
    
    return render_template('register.html')

@app.route('/dashboard')
@login_required
def dashboard():
    """Dashboard page"""
    user_name = session.get('user_name', 'Usuario')
    return render_template('dashboard.html', user_name=user_name)

@app.route('/profile')
@login_required
def profile():
    """User profile page"""
    token = session.get('access_token')
    response = make_api_request('/auth/me', token=token)
    
    if response and response.status_code == 200:
        user_data = response.json()
        return render_template('profile.html', user=user_data)
    else:
        flash('Error al cargar el perfil.', 'error')
        return redirect(url_for('dashboard'))

@app.route('/logout')
def logout():
    """Logout"""
    session.clear()
    flash('Has cerrado sesión exitosamente.', 'info')
    return redirect(url_for('login'))

@app.route('/api/validate-token', methods=['POST'])
def validate_token():
    """API endpoint to validate token"""
    token = request.json.get('token')
    
    if not token:
        return jsonify({'valid': False, 'message': 'Token no proporcionado'})
    
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return jsonify({'valid': True, 'email': payload.get('sub')})
    except jwt.ExpiredSignatureError:
        return jsonify({'valid': False, 'message': 'Token expirado'})
    except jwt.InvalidTokenError:
        return jsonify({'valid': False, 'message': 'Token inválido'})

@app.errorhandler(404)
def not_found(error):
    """404 error handler"""
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """500 error handler"""
    return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)